{
"ominous_sound"; {
"sounds"; [
"suit/ominous_sound"
  ],
 "category"; "player"
   }
}
