{
"ice"; {
"sounds"; [
"suit/ice"
  ],
 "category"; "player"
   }
}
